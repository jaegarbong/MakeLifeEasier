## Job Website opener

This program will help you to open a list of sites that aid you in job search.<br>
For e.g. I use ChatGPT, a resume editor, a JD reader to identify keywords and my email.

So this program will open all these in the browser in a single click. This is especially useful when you have a list of tools that you want to use.

### How to use this program?
1. Update the *websites.txt* file with the list of websites that you want to use.
2. Then simply run the .exe file  - "open_site.exe"
